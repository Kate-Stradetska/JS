// Створити змінні. Присвоїти кожному з них значення: 'hello','owu','com', 'ua', 1, 10, -999, 123, 3.14, 2.7, 16, true, false.
// Вивести кожну змінну за допомогою: console.log , alert, document.write

    // let values = ['hello','owu','com', 'ua', 1, 10, -999, 123, 3.14, 2.7, 16, true, false];
    // alert(values[0]);
    // alert(values[1]);
    // alert(values[2]);
    // alert(values[3]);
    // alert(values[4]);
    // alert(values[5]);
    // alert(values[6]);
    // alert(values[7]);
    // alert(values[8]);
    // alert(values[9]);
    // alert(values[10]);
    // alert(values[11]); 
    // alert(values[12]);
    // console.log(values[0]);
    // console.log(values[1]);
    // console.log(values[2]);
    // console.log(values[3]);
    // console.log(values[4]);
    // console.log(values[5]);
    // console.log(values[6]);
    // console.log(values[7]);
    // console.log(values[8]);
    // console.log(values[9]);
    // console.log(values[10]);
    // console.log(values[11]); 
    // console.log(values[12]);
    // document.write(values[0]);
    // document.write(values[1]);
    // document.write(values[2]);
    // document.write(values[3]);
    // document.write(values[4]);
    // document.write(values[5]);
    // document.write(values[6]);
    // document.write(values[7]);
    // document.write(values[8]);
    // document.write(values[9]);
    // document.write(values[10]);
    // document.write(values[11]); 
    // document.write(values[12]);

// Переприсвоїти кожну змінну з завдання вище на будь які довільні значення.
//   Вивести кожну змінну за допомогою: console.log , alert, document.write
// let values = ['hi','lp','tt', 'or', 3, 5, -9, 130, 5.75, 297, 12, true, false];
// alert(values[0]);
//     alert(values[1]);
//     alert(values[2]);
//     alert(values[3]);
//     alert(values[4]);
//     alert(values[5]);
//     alert(values[6]);
//     alert(values[7]);
//     alert(values[8]);
//     alert(values[9]);
//     alert(values[10]);
//     alert(values[11]); 
//     alert(values[12]);
//     console.log(values[0]);
//     console.log(values[1]);
//     console.log(values[2]);
//     console.log(values[3]);
//     console.log(values[4]);
//     console.log(values[5]);
//     console.log(values[6]);
//     console.log(values[7]);
//     console.log(values[8]);
//     console.log(values[9]);
//     console.log(values[10]);
//     console.log(values[11]); 
//     console.log(values[12]);
//     document.write(values[0]);
//     document.write(values[1]);
//     document.write(values[2]);
//     document.write(values[3]);
//     document.write(values[4]);
//     document.write(values[5]);
//     document.write(values[6]);
//     document.write(values[7]);
//     document.write(values[8]);
//     document.write(values[9]);
//     document.write(values[10]);
//     document.write(values[11]); 
//     document.write(values[12]);

// Створити 3 змінних firstName, middleName, lastName, наповнити їх своїм ПІБ. Зконкатенувати їх в одну змінну person.
// let firstname = 'Kate';
// let middleName = 'Stradetska';
// let lastName = 'Viktorivna';
// let user = {
//     firstname:'Kate',
//     middleName:'Stradetska',
//     lastName:'Viktorivna',

// За допомогою 3х різних prompt() отримати 3 слова які являються вашими Імям, По-Батькові та роками.
//     Вивести "Вітаю *Імя* *По батькові*. Тобі *вік* років".
// let name = prompt ('name');
// let middleName = prompt ('middlename');
// let age = prompt ('age');
// {
//     alert ( `Вітаю  ${name}.тобі ${age} років`)
// }

// За допомогою оператора typeof визначити типи наступних змінних та вивести їх в консоль.
//   let a = 100; let b = '100'; let c = true;
// console.log( typeof 100);
// console.log(typeof '100');
// console.log(typeof trye);

// Поставет відповідний оператор в виразах що б вийшов відповідний результат.
// В однакових виразаї не використовувати однакові оператори!!!
//   5 ? 6 -> true
//   5 ? 6 -> false
//   5 ? 6 -> false
//   5 ? 6 -> false
//   10 ? 10 -> true
//   10 ? 10 -> true
//   10 ? 10 -> false
//   10 ? 10 -> false
//   10 ? 10 -> false
//   123 ? '123' -> false
//   123 ? '123' -> true
// 5 > 6 -> true
//   5 < 6 -> false
//   5 = 6 -> false
//   5 == 6 -> false
//   10 = 10 -> true
//   10 == 10 -> true
//   10 > 10 -> false
//   10 < 10 -> false
//   10 <= 10 -> false
//   123 = '123' -> false
//   123 == '123' -> true